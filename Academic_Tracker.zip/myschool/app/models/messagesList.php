<?php
class messagesList extends Eloquent {
	public $timestamps = false;
	protected $table = 'messagesList';
}