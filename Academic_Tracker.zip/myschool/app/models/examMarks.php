<?php
class examMarks extends Eloquent {
	public $timestamps = false;
	protected $table = 'examMarks';
}