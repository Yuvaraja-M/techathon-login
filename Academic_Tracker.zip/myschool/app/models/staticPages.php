<?php
class staticPages extends Eloquent {
	public $timestamps = false;
	protected $table = 'staticPages';
}